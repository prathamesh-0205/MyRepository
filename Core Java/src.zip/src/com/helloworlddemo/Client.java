package com.helloworlddemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//print Hello World
		System.out.println("Hello World!!!");

	}
}
