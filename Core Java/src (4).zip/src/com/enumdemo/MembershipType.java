package com.enumdemo;

public enum MembershipType {

	NONPRIME,PRIME
}
