package com.arrayofcontainmentobjects;

public enum AccountType {
	
	SAVING,RECURRING,CURRENT
}
