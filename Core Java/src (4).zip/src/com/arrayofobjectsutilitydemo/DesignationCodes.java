package com.arrayofobjectsutilitydemo;

public enum DesignationCodes {

	SOFTWAREENGG,CONSULTANT,SENIORCONSULTANT
}
